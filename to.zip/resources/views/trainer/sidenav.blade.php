
      <div class="sidebar">
        <a class="active" href="{{ route('user.traindash') }}">Trainer Dashboaard</a>
        <a href="{{ route('user.logout') }}">Logout</a>
       

      <br>

      </div>
@yield('sidenav')
